import org.example.Router;
import org.example.models.ClientRequest;
import org.example.models.ServerResponse;
import org.example.services.Connection;
import org.example.services.ConnectionImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class RouterTests {

    private Connection clientConnection = Mockito.mock(ConnectionImpl.class);
    private Connection serverConnection = Mockito.mock(ConnectionImpl.class);
    Router router = new Router(clientConnection, serverConnection);

    @Test
    void testClientRequest() {
        ClientRequest clientRequest = new ClientRequest();
        router.fromClient(clientRequest);
        router.fromClient(clientRequest);
        router.internalRequest(clientRequest);
        router.fromClient(clientRequest);
        // Should create array of request 1 2 x 4

        ServerResponse response = new ServerResponse(4);

        var serverResponse = router.fromServer(response);
        Assertions.assertNotNull(serverResponse);
    }

    @Test
    void testInternalRequest() {
        ClientRequest clientRequest = new ClientRequest();
        router.fromClient(clientRequest);
        router.fromClient(clientRequest);
        router.internalRequest(clientRequest);
        router.fromClient(clientRequest);
        // Should create array of request 1 2 x 4

        ServerResponse response = new ServerResponse(3);

        var serverResponse = router.fromServer(response);
        Assertions.assertEquals(serverResponse, null);
    }

    // req req ireq req
    // 1    2    x    3
    // 1    2    3    4

}
