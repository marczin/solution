package org.example;

import org.example.models.ClientRequest;
import org.example.models.Packet;
import org.example.models.ServerResponse;
import org.example.services.Connection;


/*
    Client
    server
    callback
 */
//pawel.j.maciakowski@boeing.com
/*
    fix na numeracje
    nie przesylac odpowiedzi na internale
    dopisac testy (print co sie dzieje)
 */
public class Router {

    private Packet[] requests = new ClientRequest[100];
    private int pointer = 1;

    private final Connection clientConnection;
    private final Connection serverConnection;

    public Router(Connection clientConnection, Connection serverConnection) {
        this.clientConnection = clientConnection;
        this.serverConnection = serverConnection;
    }

    public void fromClient(ClientRequest request) {
        System.out.println("Iterator status: " + requests.length + ", pointer: " + pointer);
        serverConnection.send(request);
        requests[pointer] = request;
        pointer++;
        printIterations();
    }

    // can read if iterator is correct with server iteration
    public Packet fromServer(ServerResponse serverResponse) {
        System.out.println("From server: " + requests.length + ", sequence order: " + serverResponse.getSequenceOrder());
        printIterations();
        clientConnection.send(serverResponse);
        return requests[serverResponse.getSequenceOrder()];
    }

    public void internalRequest(ClientRequest request) {
        System.out.println("Internal request: " + requests.length + ", pointer: " + pointer);
        serverConnection.send(request);
        pointer++;
        printIterations();
    }

    private void printIterations() {
        System.out.print("Client requests: [ ");
        for (int i = 1; i < pointer ; i++) {
            if (requests[i] == null) {
                System.out.print("x ");
            } else {
                System.out.print(i + " ");
            }
        }
        System.out.print("]");
        System.out.println();
    }


    // req req ireq req
    // 1    2    x    3 - client iterator
    // 1    2    3    4 - server iterator


}


