package org.example.models;

public class ClientRequest implements Packet {

    @Override
    public byte[] toBytes() {
        return new byte[0];
    }
}
