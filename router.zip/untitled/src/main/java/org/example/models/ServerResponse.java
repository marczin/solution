package org.example.models;

public class ServerResponse implements Packet {

    private int sequenceOrder;

    public ServerResponse(int sequenceOrder) {
        this.sequenceOrder = sequenceOrder;
    }

    public void setSequenceOrder(int sequenceOrder) {
        this.sequenceOrder = sequenceOrder;
    }

    public int getSequenceOrder() {
        return sequenceOrder;
    }

    @Override
    public byte[] toBytes() {
        return new byte[0];
    }
}
