package org.example.models;

public interface Packet {

    byte[] toBytes();
}
