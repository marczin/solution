package org.example.services;

import org.example.models.Packet;
import org.example.models.ResponseStatus;

public class ConnectionImpl implements Connection {
    @Override
    public ResponseStatus send(Packet request) {
        return null;
    }
}
