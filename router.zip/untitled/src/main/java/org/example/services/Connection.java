package org.example.services;

import org.example.models.Packet;
import org.example.models.ResponseStatus;

public interface Connection {

    ResponseStatus send(Packet request);

}
